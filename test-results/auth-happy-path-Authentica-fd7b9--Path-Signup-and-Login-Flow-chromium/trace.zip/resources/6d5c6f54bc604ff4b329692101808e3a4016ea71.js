(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_049yqd3._.js","static/chunks/node_modules_12dt6bn._.js"],
    source: "dynamic"
});

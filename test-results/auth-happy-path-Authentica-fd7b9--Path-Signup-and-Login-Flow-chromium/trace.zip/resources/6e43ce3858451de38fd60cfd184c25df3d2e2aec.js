(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0_yjfml._.js","static/chunks/node_modules_0_r-e9v._.js"],
    source: "dynamic"
});

(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_09sf~31._.js","static/chunks/components_01~_.qo._.js"],
    source: "dynamic"
});

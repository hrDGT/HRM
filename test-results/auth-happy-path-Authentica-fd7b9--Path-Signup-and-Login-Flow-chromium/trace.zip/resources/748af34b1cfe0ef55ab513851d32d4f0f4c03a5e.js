(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0chzot6._.css","static/chunks/node_modules_0uupt64._.js","static/chunks/components_ui_sonner_tsx_122lofw._.js"],
    source: "dynamic"
});
